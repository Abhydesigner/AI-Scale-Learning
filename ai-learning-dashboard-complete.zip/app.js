// AI Learning Dashboard JavaScript
// Complete 7-Week AI Learning Curriculum

class LearningDashboard {
    constructor() {
        // Complete learning data with all weeks, tutorials, and resources
        this.data = {
            weeks: [
                {
                    id: 1,
                    title: "AI Playground Setup (Replit-Powered)",
                    description: "Set up your AI development environment and run Large Language Models locally",
                    days: [
                        {
                            id: 1,
                            title: "AI Fundamentals + Replit Introduction",
                            status: "not-started",
                            points: 10,
                            duration: "1 hour",
                            objective: "Understanding AI and LLM Fundamentals, Set up Replit account",
                            youtube: "https://www.youtube.com/watch?v=V1BR2tb_e8g",
                            resources: [
                                {name: "Replit.com", url: "https://replit.com"},
                                {name: "OpenAI Documentation", url: "https://platform.openai.com/docs"},
                                {name: "AI Basics Guide", url: "https://www.ibm.com/topics/artificial-intelligence"}
                            ],
                            tasks: [
                                "Create Replit account and explore dashboard",
                                "Browse AI templates in Replit community",
                                "Understand Replit's AI assistance features",
                                "Complete AI fundamentals reading"
                            ],
                            replitTemplate: "AI Chatbot Starter",
                            notes: "",
                            timeSpent: 0
                        },
                        {
                            id: 2,
                            title: "Local LLM with Replit Cloud",
                            status: "not-started",
                            points: 15,
                            duration: "1 hour",
                            objective: "Install and run Local Large Language Models using cloud environment",
                            youtube: "https://www.youtube.com/watch?v=kdnuggets-ollama-tutorial",
                            resources: [
                                {name: "LM Studio", url: "https://lmstudio.ai"},
                                {name: "Ollama Documentation", url: "https://ollama.ai"},
                                {name: "Local LLM Guide", url: "https://blog.n8n.io/local-llm/"}
                            ],
                            tasks: [
                                "Download and install LM Studio (GUI alternative)",
                                "Download your first model (phi3 or llama3.1)",
                                "Test model with basic conversations",
                                "Understand model parameters and settings"
                            ],
                            replitTemplate: "LLM Integration Template",
                            notes: "",
                            timeSpent: 0
                        },
                        {
                            id: 3,
                            title: "AI Chat Interface in Replit",
                            status: "not-started",
                            points: 20,
                            duration: "1 hour",
                            objective: "Build first AI chat interface using Replit templates",
                            youtube: "https://www.youtube.com/watch?v=replit-ai-chat-tutorial",
                            resources: [
                                {name: "Replit AI Templates", url: "https://replit.com/templates"},
                                {name: "Python Chatbot Guide", url: "https://realpython.com/build-a-chatbot-python-chatterbot/"},
                                {name: "Streamlit Documentation", url: "https://streamlit.io"}
                            ],
                            tasks: [
                                "Fork AI chatbot template from Replit community",
                                "Customize chatbot personality and responses",
                                "Test different conversation flows",
                                "Add basic web interface using Streamlit"
                            ],
                            replitTemplate: "Streamlit AI Chat",
                            notes: "",
                            timeSpent: 0
                        },
                        {
                            id: 4,
                            title: "Connecting AI APIs via Replit",
                            status: "not-started",
                            points: 20,
                            duration: "1 hour",
                            objective: "Connect OpenAI API and build functional chatbot",
                            youtube: "https://www.youtube.com/watch?v=openai-api-python-tutorial",
                            resources: [
                                {name: "OpenAI API Keys", url: "https://platform.openai.com/api-keys"},
                                {name: "Replit Secrets Guide", url: "https://docs.replit.com/programming-ide/workspace-features/storing-sensitive-information-environment-variables"},
                                {name: "API Integration Tutorial", url: "https://platform.openai.com/docs/quickstart"}
                            ],
                            tasks: [
                                "Get OpenAI API key and set up billing",
                                "Store API key securely in Replit Secrets",
                                "Build basic chatbot with API integration",
                                "Test different models and parameters"
                            ],
                            replitTemplate: "OpenAI API Integration",
                            notes: "",
                            timeSpent: 0
                        },
                        {
                            id: 5,
                            title: "Build Your First AI Tool",
                            status: "not-started",
                            points: 25,
                            duration: "1 hour",
                            objective: "Create deployable AI tool with web interface",
                            youtube: "https://www.youtube.com/watch?v=building-ai-tools-streamlit",
                            resources: [
                                {name: "Gradio Documentation", url: "https://gradio.app"},
                                {name: "Replit Deployment Guide", url: "https://docs.replit.com/hosting/deploying-http-servers"},
                                {name: "AI Tool Examples", url: "https://huggingface.co/spaces"}
                            ],
                            tasks: [
                                "Choose AI tool idea (text summarizer, translator, etc.)",
                                "Build tool using Gradio or Streamlit",
                                "Deploy tool on Replit with public URL",
                                "Test and gather feedback from others"
                            ],
                            replitTemplate: "AI Tool Deployment Template",
                            notes: "",
                            timeSpent: 0
                        },
                        {
                            id: 6,
                            title: "Practice & Deploy",
                            status: "not-started",
                            points: 10,
                            duration: "2 hours",
                            objective: "Consolidate learning and deploy first AI project",
                            youtube: "https://www.youtube.com/watch?v=replit-deployment-tutorial",
                            resources: [
                                {name: "Replit Community", url: "https://replit.com/community"},
                                {name: "Project Showcase Ideas", url: "https://replit.com/@replit/community-projects"},
                                {name: "Documentation Tips", url: "https://docs.replit.com"}
                            ],
                            tasks: [
                                "Refine and improve your AI tool",
                                "Add documentation and user instructions",
                                "Share project with Replit community",
                                "Plan Week 2 learning goals"
                            ],
                            replitTemplate: "Project Documentation Template",
                            notes: "",
                            timeSpent: 0
                        }
                    ]
                },
                {
                    id: 2,
                    title: "Voice Agents (No-Code + Replit Integration)",
                    description: "Build AI voice assistants using ElevenLabs and Vapi",
                    days: [
                        {
                            id: 1,
                            title: "Voice AI Fundamentals",
                            status: "not-started",
                            points: 10,
                            duration: "1 hour",
                            objective: "Understand voice AI pipeline and available tools",
                            youtube: "https://www.youtube.com/watch?v=fnivYSh0Cqk",
                            resources: [
                                {name: "ElevenLabs Platform", url: "https://elevenlabs.io"},
                                {name: "Vapi Documentation", url: "https://docs.vapi.ai"},
                                {name: "Voice AI Overview", url: "https://neon.com/guides/pulse"}
                            ],
                            tasks: [
                                "Learn about Speech-to-Text, LLM, Text-to-Speech pipeline",
                                "Explore ElevenLabs and Vapi platforms",
                                "Understand voice cloning basics",
                                "Plan your voice assistant project"
                            ],
                            replitTemplate: "Voice AI Webhook Template",
                            notes: "",
                            timeSpent: 0
                        },
                        {
                            id: 2,
                            title: "ElevenLabs Voice Cloning",
                            status: "not-started",
                            points: 20,
                            duration: "1 hour",
                            objective: "Clone your voice and test generation",
                            youtube: "https://www.youtube.com/watch?v=aMciPi1cSZA",
                            resources: [
                                {name: "ElevenLabs Voice Lab", url: "https://elevenlabs.io/voice-lab"},
                                {name: "Voice Cloning Guide", url: "https://help.elevenlabs.io/hc/en-us/articles/13313564601361-How-can-I-clone-my-voice"},
                                {name: "API Documentation", url: "https://elevenlabs.io/docs/api-reference"}
                            ],
                            tasks: [
                                "Record 2-minute voice sample (clear, varied content)",
                                "Upload and create voice clone in ElevenLabs",
                                "Test voice generation with different texts",
                                "Fine-tune voice settings for best quality"
                            ],
                            replitTemplate: "ElevenLabs API Integration",
                            notes: "",
                            timeSpent: 0
                        },
                        {
                            id: 3,
                            title: "Voice Agent Backend in Replit",
                            status: "not-started",
                            points: 25,
                            duration: "1 hour",
                            objective: "Build backend to process voice interactions",
                            youtube: "https://www.youtube.com/watch?v=building-voice-ai-backend",
                            resources: [
                                {name: "Replit Webhook Templates", url: "https://replit.com/templates/python/webhook-handler"},
                                {name: "Flask API Tutorial", url: "https://flask.palletsprojects.com/en/2.3.x/quickstart/"},
                                {name: "Voice Processing Guide", url: "https://community.n8n.io/t/elevenlabs-voice-agents-are-so-easy-to-build-no-code/72234"}
                            ],
                            tasks: [
                                "Fork voice agent backend template in Replit",
                                "Connect ElevenLabs API for voice generation",
                                "Build webhook endpoints for voice processing",
                                "Test backend with sample voice requests"
                            ],
                            replitTemplate: "Voice Agent Backend",
                            notes: "",
                            timeSpent: 0
                        },
                        {
                            id: 4,
                            title: "Vapi Integration",
                            status: "not-started",
                            points: 25,
                            duration: "1 hour",
                            objective: "Connect Vapi for complete voice assistant",
                            youtube: "https://www.youtube.com/watch?v=cuQI3UH2lDE",
                            resources: [
                                {name: "Vapi Dashboard", url: "https://dashboard.vapi.ai"},
                                {name: "Vapi Quickstart", url: "https://docs.vapi.ai/quickstart/introduction"},
                                {name: "Phone Integration Guide", url: "https://docs.vapi.ai/introduction"}
                            ],
                            tasks: [
                                "Create Vapi account and get API keys",
                                "Set up phone number for voice assistant",
                                "Connect Vapi to your Replit backend",
                                "Configure voice flows and conversation logic"
                            ],
                            replitTemplate: "Vapi Integration Template",
                            notes: "",
                            timeSpent: 0
                        },
                        {
                            id: 5,
                            title: "Complete Voice Assistant",
                            status: "not-started",
                            points: 30,
                            duration: "1 hour",
                            objective: "Deploy working voice assistant with advanced features",
                            youtube: "https://www.youtube.com/watch?v=RMOHpWAPan8",
                            resources: [
                                {name: "Advanced Vapi Features", url: "https://docs.vapi.ai/features"},
                                {name: "Voice Assistant Examples", url: "https://github.com/VapiAI/examples"},
                                {name: "Twilio Integration", url: "https://www.twilio.com/docs/voice"}
                            ],
                            tasks: [
                                "Add calendar integration to voice assistant",
                                "Implement context memory for conversations",
                                "Create custom voice commands and responses",
                                "Deploy and test complete voice assistant"
                            ],
                            replitTemplate: "Advanced Voice Assistant",
                            notes: "",
                            timeSpent: 0
                        },
                        {
                            id: 6,
                            title: "Voice Projects",
                            status: "not-started",
                            points: 15,
                            duration: "2 hours",
                            objective: "Build practical voice assistant applications",
                            youtube: "https://www.youtube.com/watch?v=voice-ai-business-applications",
                            resources: [
                                {name: "Business Voice AI Ideas", url: "https://www.salesforce.com/retail/artificial-intelligence/ai-agents-in-restaurants/"},
                                {name: "Voice UI Best Practices", url: "https://www.nngroup.com/articles/voice-ux/"},
                                {name: "Deployment Strategies", url: "https://docs.replit.com/hosting"}
                            ],
                            tasks: [
                                "Build personal voice assistant for daily tasks",
                                "Create business-focused voice agent (e.g., appointment booking)",
                                "Test with real users and gather feedback",
                                "Document and showcase your voice projects"
                            ],
                            replitTemplate: "Voice Project Showcase",
                            notes: "",
                            timeSpent: 0
                        }
                    ]
                },
                {
                    id: 3,
                    title: "AI Clones (Visual Tools + Replit Power)",
                    description: "Create personalized AI chatbots using your own knowledge base",
                    days: [
                        {
                            id: 1,
                            title: "AI Clone Fundamentals",
                            status: "not-started",
                            points: 10,
                            duration: "1 hour",
                            objective: "Understand AI clone concepts and applications",
                            youtube: "https://www.youtube.com/watch?v=3cKkArIC3jI",
                            resources: [
                                {name: "Chatbase.co", url: "https://chatbase.co"},
                                {name: "CustomGPT.ai", url: "https://customgpt.ai"},
                                {name: "AI Clone Examples", url: "https://www.gregfaxon.com/blog/ai-clone"}
                            ],
                            tasks: [
                                "Understand different approaches to AI clones",
                                "Learn about knowledge base training",
                                "Explore existing AI clone examples",
                                "Plan your personal AI clone project"
                            ],
                            replitTemplate: "AI Clone Starter",
                            notes: "",
                            timeSpent: 0
                        },
                        {
                            id: 2,
                            title: "Chatbase.co Implementation",
                            status: "not-started",
                            points: 15,
                            duration: "1 hour",
                            objective: "Build AI chatbot using Chatbase platform",
                            youtube: "https://www.youtube.com/watch?v=build-chatbot-knowledge-base",
                            resources: [
                                {name: "Chatbase Platform", url: "https://chatbase.co"},
                                {name: "Knowledge Base Guide", url: "https://knowmax.ai/blog/knowledge-base-chatbot/"},
                                {name: "Document Preparation", url: "https://support.chatbase.co/en/articles/7673623-preparing-your-data-for-training"}
                            ],
                            tasks: [
                                "Create Chatbase account",
                                "Upload your personal documents and PDFs",
                                "Train your first AI chatbot",
                                "Test and refine chatbot responses"
                            ],
                            replitTemplate: "Chatbase Integration",
                            notes: "",
                            timeSpent: 0
                        },
                        {
                            id: 3,
                            title: "Custom GPT Creation",
                            status: "not-started",
                            points: 20,
                            duration: "1 hour",
                            objective: "Create personalized AI using ChatGPT",
                            youtube: "https://www.youtube.com/watch?v=custom-gpt-tutorial",
                            resources: [
                                {name: "ChatGPT Custom GPTs", url: "https://chat.openai.com/gpts"},
                                {name: "GPT Builder Guide", url: "https://platform.openai.com/docs/assistants/overview"},
                                {name: "Custom GPT Examples", url: "https://gpt-store.com/"}
                            ],
                            tasks: [
                                "Access ChatGPT Plus for custom GPTs",
                                "Create personalized AI version of yourself",
                                "Upload knowledge files and documents",
                                "Test conversational quality and personality"
                            ],
                            replitTemplate: "Custom GPT Integration",
                            notes: "",
                            timeSpent: 0
                        },
                        {
                            id: 4,
                            title: "Advanced Clone with Replit",
                            status: "not-started",
                            points: 25,
                            duration: "1 hour",
                            objective: "Build sophisticated AI clone with memory",
                            youtube: "https://www.youtube.com/watch?v=Uamd3UJ7n2k",
                            resources: [
                                {name: "LangChain Documentation", url: "https://python.langchain.com/docs/get_started/introduction.html"},
                                {name: "Vector Databases", url: "https://www.pinecone.io/learn/vector-database/"},
                                {name: "Memory Systems", url: "https://python.langchain.com/docs/modules/memory/"}
                            ],
                            tasks: [
                                "Build AI clone with persistent memory",
                                "Implement knowledge base search",
                                "Add personality traits and speaking style",
                                "Create context-aware responses"
                            ],
                            replitTemplate: "Advanced AI Clone",
                            notes: "",
                            timeSpent: 0
                        },
                        {
                            id: 5,
                            title: "Web Interface for Clone",
                            status: "not-started",
                            points: 25,
                            duration: "1 hour",
                            objective: "Deploy AI clone with professional web interface",
                            youtube: "https://www.youtube.com/watch?v=streamlit-chatbot-interface",
                            resources: [
                                {name: "Streamlit Chat", url: "https://docs.streamlit.io/library/api-reference/chat"},
                                {name: "Gradio Chatbot", url: "https://gradio.app/docs/#chatbot"},
                                {name: "Web Interface Examples", url: "https://huggingface.co/spaces"}
                            ],
                            tasks: [
                                "Create professional web interface",
                                "Add chat history and memory",
                                "Implement user authentication",
                                "Deploy with custom domain"
                            ],
                            replitTemplate: "Clone Web Interface",
                            notes: "",
                            timeSpent: 0
                        },
                        {
                            id: 6,
                            title: "Clone Deployment",
                            status: "not-started",
                            points: 15,
                            duration: "2 hours",
                            objective: "Deploy and showcase AI clone projects",
                            youtube: "https://www.youtube.com/watch?v=ai-clone-deployment",
                            resources: [
                                {name: "Replit Hosting", url: "https://docs.replit.com/hosting"},
                                {name: "Custom Domains", url: "https://docs.replit.com/hosting/custom-domains"},
                                {name: "Analytics Integration", url: "https://analytics.google.com/"}
                            ],
                            tasks: [
                                "Deploy multiple AI clone variations",
                                "Create showcase portfolio",
                                "Gather user feedback and testimonials",
                                "Plan monetization strategies"
                            ],
                            replitTemplate: "Clone Portfolio",
                            notes: "",
                            timeSpent: 0
                        }
                    ]
                },
                {
                    id: 4,
                    title: "AI Content Generation",
                    description: "Generate AI-powered videos, audio, and visual content",
                    days: [
                        {
                            id: 1,
                            title: "Content Generation Overview",
                            status: "not-started",
                            points: 10,
                            duration: "1 hour",
                            objective: "Explore AI content creation landscape",
                            youtube: "https://www.youtube.com/watch?v=iln0fOakWpM",
                            resources: [
                                {name: "HeyGen", url: "https://heygen.com"},
                                {name: "RunwayML", url: "https://runwayml.com"},
                                {name: "InVideo AI", url: "https://invideo.io/ai/"}
                            ],
                            tasks: [
                                "Explore different AI content platforms",
                                "Understand text-to-video technology",
                                "Learn about AI avatars and voice synthesis",
                                "Plan your content creation strategy"
                            ],
                            replitTemplate: "Content Planning Tool",
                            notes: "",
                            timeSpent: 0
                        },
                        {
                            id: 2,
                            title: "HeyGen AI Videos",
                            status: "not-started",
                            points: 20,
                            duration: "1 hour",
                            objective: "Create AI avatar and generate videos",
                            youtube: "https://www.youtube.com/watch?v=eFwx6fyDOmU",
                            resources: [
                                {name: "HeyGen Studio", url: "https://app.heygen.com"},
                                {name: "Avatar Creation Guide", url: "https://help.heygen.com/en/articles/6930113-how-to-create-an-avatar"},
                                {name: "Video Templates", url: "https://www.heygen.com/templates"}
                            ],
                            tasks: [
                                "Create HeyGen account and record avatar",
                                "Generate your first AI video",
                                "Experiment with different templates",
                                "Create business presentation videos"
                            ],
                            replitTemplate: "HeyGen API Integration",
                            notes: "",
                            timeSpent: 0
                        },
                        {
                            id: 3,
                            title: "RunwayML Creative Content",
                            status: "not-started",
                            points: 20,
                            duration: "1 hour",
                            objective: "Generate images and videos using RunwayML",
                            youtube: "https://www.youtube.com/watch?v=c38vtLw1nSk",
                            resources: [
                                {name: "RunwayML Studio", url: "https://app.runwayml.com"},
                                {name: "Gen-2 Video", url: "https://research.runwayml.com/gen2"},
                                {name: "Creative Tutorials", url: "https://academy.runwayml.com"}
                            ],
                            tasks: [
                                "Learn RunwayML interface and tools",
                                "Generate images from text prompts",
                                "Create videos using Gen-2 technology",
                                "Experiment with creative editing features"
                            ],
                            replitTemplate: "RunwayML Workflow",
                            notes: "",
                            timeSpent: 0
                        },
                        {
                            id: 4,
                            title: "Content Automation with Replit",
                            status: "not-started",
                            points: 25,
                            duration: "1 hour",
                            objective: "Automate content creation workflows",
                            youtube: "https://www.youtube.com/watch?v=content-automation-tutorial",
                            resources: [
                                {name: "Content APIs", url: "https://rapidapi.com/collection/content-generation-apis"},
                                {name: "Automation Templates", url: "https://replit.com/templates"},
                                {name: "Scheduling Tools", url: "https://docs.python.org/3/library/sched.html"}
                            ],
                            tasks: [
                                "Build automated content generation pipeline",
                                "Connect multiple AI content APIs",
                                "Create batch processing systems",
                                "Schedule automated content creation"
                            ],
                            replitTemplate: "Content Automation Hub",
                            notes: "",
                            timeSpent: 0
                        },
                        {
                            id: 5,
                            title: "Content Distribution System",
                            status: "not-started",
                            points: 25,
                            duration: "1 hour",
                            objective: "Build automated posting and distribution",
                            youtube: "https://www.youtube.com/watch?v=social-media-automation",
                            resources: [
                                {name: "Social Media APIs", url: "https://developers.facebook.com/docs/"},
                                {name: "YouTube API", url: "https://developers.google.com/youtube/v3"},
                                {name: "Scheduling Services", url: "https://buffer.com/developers"}
                            ],
                            tasks: [
                                "Connect social media APIs",
                                "Build automated posting system",
                                "Create content scheduling dashboard",
                                "Implement analytics tracking"
                            ],
                            replitTemplate: "Distribution System",
                            notes: "",
                            timeSpent: 0
                        },
                        {
                            id: 6,
                            title: "Content Empire",
                            status: "not-started",
                            points: 15,
                            duration: "2 hours",
                            objective: "Build complete automated content business",
                            youtube: "https://www.youtube.com/watch?v=content-business-automation",
                            resources: [
                                {name: "Business Models", url: "https://blog.hootsuite.com/social-media-business-models/"},
                                {name: "Monetization Strategies", url: "https://creatoreconomy.so/p/creator-economy-monetization"},
                                {name: "Analytics Tools", url: "https://analytics.google.com/"}
                            ],
                            tasks: [
                                "Deploy end-to-end content system",
                                "Create multiple content channels",
                                "Implement monetization strategies",
                                "Build analytics and reporting"
                            ],
                            replitTemplate: "Content Business Suite",
                            notes: "",
                            timeSpent: 0
                        }
                    ]
                },
                {
                    id: 5,
                    title: "AI Automations",
                    description: "Build full automation stacks using n8n and workflow tools",
                    days: [
                        {
                            id: 1,
                            title: "Automation Fundamentals",
                            status: "not-started",
                            points: 10,
                            duration: "1 hour",
                            objective: "Learn workflow automation concepts",
                            youtube: "https://www.youtube.com/watch?v=4cQWJViybAQ",
                            resources: [
                                {name: "n8n Platform", url: "https://n8n.io"},
                                {name: "Make.com", url: "https://make.com"},
                                {name: "Zapier", url: "https://zapier.com"}
                            ],
                            tasks: [
                                "Understand triggers, actions, and data flow",
                                "Explore n8n platform and interface",
                                "Learn about API connections",
                                "Plan your first automation workflow"
                            ],
                            replitTemplate: "Automation Planner",
                            notes: "",
                            timeSpent: 0
                        },
                        {
                            id: 2,
                            title: "n8n Visual Workflows",
                            status: "not-started",
                            points: 20,
                            duration: "1 hour",
                            objective: "Build workflows using n8n visual editor",
                            youtube: "https://www.youtube.com/watch?v=lSwMtsm6oDU",
                            resources: [
                                {name: "n8n Cloud", url: "https://app.n8n.cloud"},
                                {name: "Workflow Templates", url: "https://n8n.io/workflows/"},
                                {name: "Node Documentation", url: "https://docs.n8n.io/integrations/"}
                            ],
                            tasks: [
                                "Create n8n cloud account",
                                "Build simple email automation workflow",
                                "Connect multiple services together",
                                "Test and debug workflow execution"
                            ],
                            replitTemplate: "n8n Webhook Handler",
                            notes: "",
                            timeSpent: 0
                        },
                        {
                            id: 3,
                            title: "Replit as Automation Backend",
                            status: "not-started",
                            points: 25,
                            duration: "1 hour",
                            objective: "Use Replit as processing backend for workflows",
                            youtube: "https://www.youtube.com/watch?v=DkV7ztrhLh8",
                            resources: [
                                {name: "Webhook Integration", url: "https://docs.replit.com/tutorials/python/build-with-webhooks"},
                                {name: "API Development", url: "https://flask.palletsprojects.com/en/2.3.x/"},
                                {name: "Database Integration", url: "https://docs.replit.com/hosting/database"}
                            ],
                            tasks: [
                                "Create webhook endpoints in Replit",
                                "Connect n8n workflows to Replit backend",
                                "Process data using AI in Replit",
                                "Return results to workflow automation"
                            ],
                            replitTemplate: "Automation Backend API",
                            notes: "",
                            timeSpent: 0
                        },
                        {
                            id: 4,
                            title: "Advanced Automation Workflows",
                            status: "not-started",
                            points: 25,
                            duration: "1 hour",
                            objective: "Build complex multi-step automations",
                            youtube: "https://www.youtube.com/watch?v=VUmo6AviDxQ",
                            resources: [
                                {name: "Complex Workflows", url: "https://docs.n8n.io/workflows/"},
                                {name: "Error Handling", url: "https://docs.n8n.io/workflows/error-handling/"},
                                {name: "Conditional Logic", url: "https://docs.n8n.io/nodes/n8n-nodes-base.if/"}
                            ],
                            tasks: [
                                "Build lead qualification automation",
                                "Create customer support workflows",
                                "Implement conditional logic and branching",
                                "Add error handling and monitoring"
                            ],
                            replitTemplate: "Complex Workflow System",
                            notes: "",
                            timeSpent: 0
                        },
                        {
                            id: 5,
                            title: "Business Process Automation",
                            status: "not-started",
                            points: 30,
                            duration: "1 hour",
                            objective: "Automate end-to-end business processes",
                            youtube: "https://www.youtube.com/watch?v=business-automation-tutorial",
                            resources: [
                                {name: "Business Templates", url: "https://n8n.io/workflows/?categories=business"},
                                {name: "CRM Integration", url: "https://docs.n8n.io/integrations/builtin/app-nodes/n8n-nodes-base.hubspot/"},
                                {name: "Email Marketing", url: "https://docs.n8n.io/integrations/builtin/app-nodes/n8n-nodes-base.mailchimp/"}
                            ],
                            tasks: [
                                "Automate customer onboarding process",
                                "Build invoice generation and tracking",
                                "Create lead nurturing campaigns",
                                "Implement business reporting automation"
                            ],
                            replitTemplate: "Business Automation Suite",
                            notes: "",
                            timeSpent: 0
                        },
                        {
                            id: 6,
                            title: "Deploy Automation Systems",
                            status: "not-started",
                            points: 15,
                            duration: "2 hours",
                            objective: "Deploy and scale automation systems",
                            youtube: "https://www.youtube.com/watch?v=automation-deployment",
                            resources: [
                                {name: "Production Deployment", url: "https://docs.n8n.io/hosting/"},
                                {name: "Monitoring Tools", url: "https://docs.n8n.io/hosting/logging-monitoring/"},
                                {name: "Scaling Strategies", url: "https://docs.n8n.io/hosting/scaling/"}
                            ],
                            tasks: [
                                "Deploy automations to production",
                                "Set up monitoring and alerts",
                                "Create client dashboards",
                                "Build automation consulting business"
                            ],
                            replitTemplate: "Automation Business Kit",
                            notes: "",
                            timeSpent: 0
                        }
                    ]
                },
                {
                    id: 6,
                    title: "AI Agents",
                    description: "Build autonomous AI agents that execute multi-step tasks",
                    days: [
                        {
                            id: 1,
                            title: "AI Agent Fundamentals",
                            status: "not-started",
                            points: 15,
                            duration: "1 hour",
                            objective: "Understand agent architecture and capabilities",
                            youtube: "https://www.youtube.com/watch?v=ai-agents-explained",
                            resources: [
                                {name: "LangChain Agents", url: "https://python.langchain.com/docs/modules/agents/"},
                                {name: "Agent Types", url: "https://python.langchain.com/docs/modules/agents/agent_types/"},
                                {name: "Tools and Toolkits", url: "https://python.langchain.com/docs/modules/agents/tools/"}
                            ],
                            tasks: [
                                "Learn difference between automation and agents",
                                "Understand agent decision-making process",
                                "Explore available agent frameworks",
                                "Plan your first autonomous agent"
                            ],
                            replitTemplate: "Agent Architecture",
                            notes: "",
                            timeSpent: 0
                        },
                        {
                            id: 2,
                            title: "Research Agent in Replit",
                            status: "not-started",
                            points: 25,
                            duration: "1 hour",
                            objective: "Build autonomous research and information gathering agent",
                            youtube: "https://www.youtube.com/watch?v=research-agent-tutorial",
                            resources: [
                                {name: "Web Scraping Tools", url: "https://requests.readthedocs.io/en/latest/"},
                                {name: "Search APIs", url: "https://serpapi.com/"},
                                {name: "Data Processing", url: "https://pandas.pydata.org/"}
                            ],
                            tasks: [
                                "Build web scraping capabilities",
                                "Integrate search APIs",
                                "Create information synthesis system",
                                "Deploy research agent with web interface"
                            ],
                            replitTemplate: "Research Agent",
                            notes: "",
                            timeSpent: 0
                        },
                        {
                            id: 3,
                            title: "Multi-Agent System",
                            status: "not-started",
                            points: 30,
                            duration: "1 hour",
                            objective: "Create coordinated team of specialized agents",
                            youtube: "https://www.youtube.com/watch?v=multi-agent-systems",
                            resources: [
                                {name: "Agent Communication", url: "https://python.langchain.com/docs/use_cases/agent_simulations/"},
                                {name: "Task Delegation", url: "https://python.langchain.com/docs/modules/agents/how_to/intermediate_steps"},
                                {name: "Coordination Patterns", url: "https://microsoft.github.io/autogen/"}
                            ],
                            tasks: [
                                "Design agent specialization strategy",
                                "Implement agent-to-agent communication",
                                "Build task delegation system",
                                "Create agent coordination dashboard"
                            ],
                            replitTemplate: "Multi-Agent Framework",
                            notes: "",
                            timeSpent: 0
                        },
                        {
                            id: 4,
                            title: "Customer Service Agent",
                            status: "not-started",
                            points: 25,
                            duration: "1 hour",
                            objective: "Deploy autonomous customer support system",
                            youtube: "https://www.youtube.com/watch?v=customer-service-ai",
                            resources: [
                                {name: "Customer Service APIs", url: "https://developers.zendesk.com/api-reference/"},
                                {name: "Knowledge Base Integration", url: "https://python.langchain.com/docs/modules/data_connection/"},
                                {name: "Escalation Logic", url: "https://docs.python.org/3/library/logging.html"}
                            ],
                            tasks: [
                                "Build ticket classification system",
                                "Create automated response generation",
                                "Implement escalation to human agents",
                                "Deploy with help desk integration"
                            ],
                            replitTemplate: "Customer Service Agent",
                            notes: "",
                            timeSpent: 0
                        },
                        {
                            id: 5,
                            title: "Advanced Agent Deployment",
                            status: "not-started",
                            points: 30,
                            duration: "1 hour",
                            objective: "Scale and deploy production-ready agents",
                            youtube: "https://www.youtube.com/watch?v=agent-deployment-scaling",
                            resources: [
                                {name: "Agent Monitoring", url: "https://docs.langchain.com/docs/integrations/tracing/"},
                                {name: "Performance Optimization", url: "https://python.langchain.com/docs/guides/debugging/"},
                                {name: "Cost Management", url: "https://platform.openai.com/docs/guides/production-best-practices"}
                            ],
                            tasks: [
                                "Implement agent monitoring and logging",
                                "Optimize performance and reduce costs",
                                "Create agent management dashboard",
                                "Set up automated testing and deployment"
                            ],
                            replitTemplate: "Production Agent System",
                            notes: "",
                            timeSpent: 0
                        },
                        {
                            id: 6,
                            title: "Agent Ecosystem",
                            status: "not-started",
                            points: 20,
                            duration: "2 hours",
                            objective: "Build complete autonomous agent business",
                            youtube: "https://www.youtube.com/watch?v=agent-business-model",
                            resources: [
                                {name: "Agent Marketplaces", url: "https://huggingface.co/models?pipeline_tag=text-generation"},
                                {name: "Business Models", url: "https://www.mckinsey.com/capabilities/mckinsey-digital/our-insights/the-economic-potential-of-generative-ai"},
                                {name: "Client Integration", url: "https://docs.replit.com/hosting/custom-domains"}
                            ],
                            tasks: [
                                "Deploy multiple specialized agents",
                                "Create agent marketplace or directory",
                                "Build client onboarding system",
                                "Develop agent consulting services"
                            ],
                            replitTemplate: "Agent Business Platform",
                            notes: "",
                            timeSpent: 0
                        }
                    ]
                },
                {
                    id: 7,
                    title: "No-Code AI Products",
                    description: "Build complete AI products using no-code platforms",
                    days: [
                        {
                            id: 1,
                            title: "Product Planning",
                            status: "not-started",
                            points: 15,
                            duration: "1 hour",
                            objective: "Design and plan your AI product",
                            youtube: "https://www.youtube.com/watch?v=product-planning-guide",
                            resources: [
                                {name: "Product Strategy", url: "https://www.productplan.com/glossary/product-strategy/"},
                                {name: "User Research", url: "https://www.nngroup.com/articles/which-ux-research-methods/"},
                                {name: "Market Analysis", url: "https://blog.hubspot.com/marketing/how-to-do-market-research"}
                            ],
                            tasks: [
                                "Define target market and user personas",
                                "Create product feature specifications",
                                "Design user experience and workflows",
                                "Plan technical architecture"
                            ],
                            replitTemplate: "Product Planning Tool",
                            notes: "",
                            timeSpent: 0
                        },
                        {
                            id: 2,
                            title: "Frontend with Bubble.io",
                            status: "not-started",
                            points: 25,
                            duration: "1 hour",
                            objective: "Build user interface using Bubble.io",
                            youtube: "https://www.youtube.com/watch?v=n8iM5Oeiz9k",
                            resources: [
                                {name: "Bubble Academy", url: "https://bubble.io/academy"},
                                {name: "UI Templates", url: "https://bubble.io/templates"},
                                {name: "Responsive Design", url: "https://manual.bubble.io/design/responsive-design"}
                            ],
                            tasks: [
                                "Create Bubble.io app structure",
                                "Design responsive user interface",
                                "Set up user authentication system",
                                "Build core application workflows"
                            ],
                            replitTemplate: "Bubble Backend Connector",
                            notes: "",
                            timeSpent: 0
                        },
                        {
                            id: 3,
                            title: "AI Backend with Replit",
                            status: "not-started",
                            points: 30,
                            duration: "1 hour",
                            objective: "Connect AI processing backend",
                            youtube: "https://www.youtube.com/watch?v=bubble-replit-integration",
                            resources: [
                                {name: "API Connector", url: "https://manual.bubble.io/core-resources/api-connector"},
                                {name: "Webhook Integration", url: "https://docs.replit.com/tutorials/python/build-with-webhooks"},
                                {name: "Database Design", url: "https://docs.replit.com/hosting/database"}
                            ],
                            tasks: [
                                "Build AI processing APIs in Replit",
                                "Connect Bubble frontend to Replit backend",
                                "Implement data processing workflows",
                                "Set up database and user data management"
                            ],
                            replitTemplate: "AI Product Backend",
                            notes: "",
                            timeSpent: 0
                        },
                        {
                            id: 4,
                            title: "Advanced Features",
                            status: "not-started",
                            points: 25,
                            duration: "1 hour",
                            objective: "Add payments, analytics, and premium features",
                            youtube: "https://www.youtube.com/watch?v=bubble-advanced-features",
                            resources: [
                                {name: "Stripe Integration", url: "https://stripe.com/docs/no-code"},
                                {name: "Analytics Setup", url: "https://analytics.google.com/"},
                                {name: "Email Integration", url: "https://manual.bubble.io/core-resources/email"}
                            ],
                            tasks: [
                                "Implement payment processing with Stripe",
                                "Add user analytics and tracking",
                                "Create email notification system",
                                "Build admin dashboard and controls"
                            ],
                            replitTemplate: "Payment Processing API",
                            notes: "",
                            timeSpent: 0
                        },
                        {
                            id: 5,
                            title: "Testing & Deployment",
                            status: "not-started",
                            points: 25,
                            duration: "1 hour",
                            objective: "Test, optimize, and deploy your product",
                            youtube: "https://www.youtube.com/watch?v=bubble-deployment-guide",
                            resources: [
                                {name: "Testing Guide", url: "https://manual.bubble.io/maintaining-an-application/testing"},
                                {name: "Performance Optimization", url: "https://manual.bubble.io/maintaining-an-application/performance"},
                                {name: "Custom Domains", url: "https://manual.bubble.io/maintaining-an-application/custom-domain"}
                            ],
                            tasks: [
                                "Conduct user testing and gather feedback",
                                "Optimize application performance",
                                "Set up custom domain and SSL",
                                "Create user documentation and support"
                            ],
                            replitTemplate: "Testing & Analytics Suite",
                            notes: "",
                            timeSpent: 0
                        },
                        {
                            id: 6,
                            title: "Product Launch",
                            status: "not-started",
                            points: 25,
                            duration: "2 hours",
                            objective: "Launch and market your AI product",
                            youtube: "https://www.youtube.com/watch?v=product-launch-strategy",
                            resources: [
                                {name: "Launch Strategy", url: "https://blog.hubspot.com/marketing/elements-perfect-product-launch"},
                                {name: "Marketing Automation", url: "https://mailchimp.com/marketing-automation/"},
                                {name: "Customer Support", url: "https://www.zendesk.com/"}
                            ],
                            tasks: [
                                "Create marketing website and landing pages",
                                "Launch product with beta users",
                                "Implement feedback collection system",
                                "Build sustainable business operations"
                            ],
                            replitTemplate: "Launch & Marketing Kit",
                            notes: "",
                            timeSpent: 0
                        }
                    ]
                }
            ],
            achievements: [
                {id: 1, name: "First Steps", description: "Complete your first day", icon: "🎯", unlocked: false, points: 50},
                {id: 2, name: "Week Warrior", description: "Complete an entire week", icon: "⚡", unlocked: false, points: 200},
                {id: 3, name: "Streak Master", description: "5 days learning streak", icon: "🔥", unlocked: false, points: 150},
                {id: 4, name: "AI Builder", description: "Complete first 3 weeks", icon: "🤖", unlocked: false, points: 500},
                {id: 5, name: "Voice Commander", description: "Complete Voice Agents week", icon: "🎤", unlocked: false, points: 300},
                {id: 6, name: "Clone Master", description: "Complete AI Clones week", icon: "👥", unlocked: false, points: 350},
                {id: 7, name: "Content Creator", description: "Complete Content Generation week", icon: "🎬", unlocked: false, points: 400},
                {id: 8, name: "Automation Expert", description: "Complete Automations week", icon: "⚙️", unlocked: false, points: 450},
                {id: 9, name: "Agent Master", description: "Complete AI Agents week", icon: "🤝", unlocked: false, points: 500},
                {id: 10, name: "Product Builder", description: "Complete No-Code Products week", icon: "🏗️", unlocked: false, points: 550},
                {id: 11, name: "AI Graduate", description: "Complete all 7 weeks", icon: "🎓", unlocked: false, points: 1000}
            ],
            tools: [
                {name: "Replit", url: "https://replit.com", category: "Development", description: "Cloud development environment with AI assistance"},
                {name: "ElevenLabs", url: "https://elevenlabs.io", category: "Voice AI", description: "Voice cloning and generation platform"},
                {name: "Vapi", url: "https://vapi.ai", category: "Voice AI", description: "Voice agent and phone integration platform"},
                {name: "OpenAI", url: "https://platform.openai.com", category: "AI APIs", description: "GPT models and AI APIs"},
                {name: "n8n", url: "https://n8n.io", category: "Automation", description: "Visual workflow automation platform"},
                {name: "HeyGen", url: "https://heygen.com", category: "Video AI", description: "AI avatar and video generation"},
                {name: "RunwayML", url: "https://runwayml.com", category: "Creative AI", description: "AI-powered creative tools"},
                {name: "Bubble.io", url: "https://bubble.io", category: "No-Code", description: "Visual web application builder"},
                {name: "Webflow", url: "https://webflow.com", category: "No-Code", description: "Visual website design and development"},
                {name: "LM Studio", url: "https://lmstudio.ai", category: "Local AI", description: "Run LLMs locally with GUI interface"},
                {name: "Chatbase", url: "https://chatbase.co", category: "AI Tools", description: "Custom AI chatbot platform"},
                {name: "Make.com", url: "https://make.com", category: "Automation", description: "Visual automation and integration platform"},
                {name: "Zapier", url: "https://zapier.com", category: "Automation", description: "App automation and workflow platform"},
                {name: "Gradio", url: "https://gradio.app", category: "AI Tools", description: "Build and share machine learning apps"},
                {name: "Streamlit", url: "https://streamlit.io", category: "AI Tools", description: "Build and share data apps"},
                {name: "LangChain", url: "https://python.langchain.com", category: "AI Framework", description: "Framework for developing LLM applications"}
            ],
            userProgress: {
                totalPoints: 0,
                currentLevel: "Beginner",
                currentWeek: 1,
                completedTasks: 0,
                learningStreak: 0,
                totalTimeSpent: 0
            }
        };

        this.init();
    }

    init() {
        this.setupEventListeners();
        this.renderOverview();
        this.renderCurriculum();
        this.renderWeeklyProgress();
        this.renderResources();
        this.renderAchievements();
        this.updateStats();
    }

    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                this.switchView(item.dataset.view);
            });
        });
    }

    switchView(view) {
        // Hide all content sections
        document.querySelectorAll('.content-section').forEach(section => {
            section.classList.remove('active');
        });

        // Show selected section
        const targetSection = document.getElementById(`${view}-content`);
        if (targetSection) {
            targetSection.classList.add('active');
        }

        // Update navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
        });
        const activeItem = document.querySelector(`[data-view="${view}"]`);
        if (activeItem) {
            activeItem.classList.add('active');
        }
    }

    renderCurriculum() {
        const container = document.getElementById('curriculumContainer');
        if (!container) return;

        container.innerHTML = this.data.weeks.map(week => `
            <div class="week-card" id="week-${week.id}">
                <div class="week-header">
                    <h2>Week ${week.id}: ${week.title}</h2>
                    <p>${week.description}</p>
                    <div class="week-progress">
                        <div class="progress-bar">
                            <div class="progress-fill" style="width: ${this.getWeekProgress(week.id)}%"></div>
                        </div>
                        <span>${this.getWeekProgress(week.id)}% Complete</span>
                    </div>
                </div>
                <div class="days-grid">
                    ${week.days.map(day => `
                        <div class="day-card ${day.status}" id="day-${week.id}-${day.id}">
                            <div class="day-header">
                                <h3>Day ${day.id}: ${day.title}</h3>
                                <span class="status-badge ${day.status}">${day.status.replace('-', ' ')}</span>
                            </div>
                            <div class="day-content">
                                <div class="day-meta">
                                    <span><i class="fas fa-clock"></i> ${day.duration}</span>
                                    <span><i class="fas fa-star"></i> ${day.points} points</span>
                                </div>
                                <p class="objective"><strong>Objective:</strong> ${day.objective}</p>

                                <div class="resources-section">
                                    <h4><i class="fas fa-play"></i> Tutorial:</h4>
                                    <a href="${day.youtube}" target="_blank" class="youtube-link">
                                        <i class="fab fa-youtube"></i> Watch Tutorial
                                    </a>

                                    <h4><i class="fas fa-link"></i> Resources:</h4>
                                    <div class="resource-links">
                                        ${day.resources.map(resource => `
                                            <a href="${resource.url}" target="_blank" class="resource-link">
                                                <i class="fas fa-external-link-alt"></i> ${resource.name}
                                            </a>
                                        `).join('')}
                                    </div>

                                    <h4><i class="fas fa-tasks"></i> Tasks:</h4>
                                    <ul class="task-list">
                                        ${day.tasks.map(task => `<li>${task}</li>`).join('')}
                                    </ul>

                                    <div class="replit-template">
                                        <i class="fas fa-code"></i> Replit Template: <strong>${day.replitTemplate}</strong>
                                    </div>
                                </div>

                                <div class="day-actions">
                                    <button class="btn btn-primary mark-complete" data-week="${week.id}" data-day="${day.id}">
                                        <i class="fas fa-check"></i> ${day.status === 'completed' ? 'Completed' : 'Mark Complete'}
                                    </button>
                                    <button class="btn btn-secondary add-notes" data-week="${week.id}" data-day="${day.id}">
                                        <i class="fas fa-sticky-note"></i> Add Notes
                                    </button>
                                </div>

                                ${day.notes ? `
                                    <div class="notes-section">
                                        <h4><i class="fas fa-sticky-note"></i> Your Notes:</h4>
                                        <p>${day.notes}</p>
                                    </div>
                                ` : ''}
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `).join('');

        this.setupTaskButtons();
    }

    renderWeeklyProgress() {
        const container = document.getElementById('weeklyProgressContainer');
        if (!container) return;

        container.innerHTML = `
            <div class="progress-overview">
                <div class="progress-stats">
                    <div class="stat-card">
                        <h3>Overall Progress</h3>
                        <div class="big-number">${this.getOverallProgress()}%</div>
                        <div class="progress-bar">
                            <div class="progress-fill" style="width: ${this.getOverallProgress()}%"></div>
                        </div>
                    </div>
                    <div class="stat-card">
                        <h3>Total Points</h3>
                        <div class="big-number">${this.data.userProgress.totalPoints}</div>
                        <p>Keep learning to earn more!</p>
                    </div>
                    <div class="stat-card">
                        <h3>Learning Streak</h3>
                        <div class="big-number">${this.data.userProgress.learningStreak}</div>
                        <p>days in a row</p>
                    </div>
                </div>

                <div class="weekly-breakdown">
                    ${this.data.weeks.map(week => `
                        <div class="week-progress-item">
                            <div class="week-info">
                                <h4>Week ${week.id}: ${week.title}</h4>
                                <p>${this.getCompletedTasksInWeek(week.id)}/${week.days.length} tasks completed</p>
                            </div>
                            <div class="week-progress-bar">
                                <div class="progress-fill" style="width: ${this.getWeekProgress(week.id)}%"></div>
                            </div>
                            <span class="progress-percentage">${this.getWeekProgress(week.id)}%</span>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }

    renderResources() {
        const container = document.getElementById('resourcesContainer');
        if (!container) return;

        const toolsByCategory = this.data.tools.reduce((acc, tool) => {
            if (!acc[tool.category]) acc[tool.category] = [];
            acc[tool.category].push(tool);
            return acc;
        }, {});

        container.innerHTML = Object.keys(toolsByCategory).map(category => `
            <div class="resource-category">
                <h2><i class="fas fa-tools"></i> ${category}</h2>
                <div class="resource-grid">
                    ${toolsByCategory[category].map(tool => `
                        <div class="resource-card">
                            <h3>${tool.name}</h3>
                            <p>${tool.description}</p>
                            <a href="${tool.url}" target="_blank" class="btn btn-primary">
                                <i class="fas fa-external-link-alt"></i> Open ${tool.name}
                            </a>
                        </div>
                    `).join('')}
                </div>
            </div>
        `).join('');
    }

    renderAchievements() {
        const container = document.getElementById('achievementsContainer');
        if (!container) return;

        container.innerHTML = `
            <div class="achievements-grid">
                ${this.data.achievements.map(achievement => `
                    <div class="achievement-card ${achievement.unlocked ? 'unlocked' : ''}">
                        <div class="achievement-icon">${achievement.icon}</div>
                        <h3>${achievement.name}</h3>
                        <p>${achievement.description}</p>
                        <div class="achievement-points">
                            <i class="fas fa-star"></i> ${achievement.points} points
                        </div>
                        ${achievement.unlocked ? '<div class="unlocked-badge">✓ Unlocked!</div>' : '<div class="locked-badge">🔒 Locked</div>'}
                    </div>
                `).join('')}
            </div>
        `;
    }

    setupTaskButtons() {
        // Mark complete buttons
        document.querySelectorAll('.mark-complete').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const weekId = parseInt(e.target.dataset.week);
                const dayId = parseInt(e.target.dataset.day);
                this.markTaskComplete(weekId, dayId);
            });
        });

        // Add notes buttons
        document.querySelectorAll('.add-notes').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const weekId = parseInt(e.target.dataset.week);
                const dayId = parseInt(e.target.dataset.day);
                this.addNotes(weekId, dayId);
            });
        });
    }

    markTaskComplete(weekId, dayId) {
        const week = this.data.weeks.find(w => w.id === weekId);
        const day = week.days.find(d => d.id === dayId);

        if (day.status !== 'completed') {
            day.status = 'completed';
            this.data.userProgress.totalPoints += day.points;
            this.data.userProgress.completedTasks++;

            // Check for achievements
            this.checkAchievements();

            // Update displays
            this.updateStats();
            this.renderCurriculum();
            this.renderWeeklyProgress();
            this.showAchievementNotification(day.points);

            // Update current week display
            this.updateCurrentWeekDisplay();
        }
    }

    addNotes(weekId, dayId) {
        const week = this.data.weeks.find(w => w.id === weekId);
        const day = week.days.find(d => d.id === dayId);

        const notes = prompt(`Add notes for "${day.title}":`, day.notes || '');
        if (notes !== null) {
            day.notes = notes;
            this.renderCurriculum();
        }
    }

    checkAchievements() {
        const completedTasks = this.getTotalCompletedTasks();
        const completedWeeks = this.getCompletedWeeks();

        // Check each achievement
        this.data.achievements.forEach(achievement => {
            if (!achievement.unlocked) {
                let shouldUnlock = false;

                switch (achievement.id) {
                    case 1: // First Steps
                        shouldUnlock = completedTasks >= 1;
                        break;
                    case 2: // Week Warrior
                        shouldUnlock = completedWeeks >= 1;
                        break;
                    case 3: // Streak Master (simplified for demo)
                        shouldUnlock = completedTasks >= 5;
                        break;
                    case 4: // AI Builder
                        shouldUnlock = completedWeeks >= 3;
                        break;
                    case 5: // Voice Commander
                        shouldUnlock = this.getWeekProgress(2) === 100;
                        break;
                    case 6: // Clone Master
                        shouldUnlock = this.getWeekProgress(3) === 100;
                        break;
                    case 7: // Content Creator
                        shouldUnlock = this.getWeekProgress(4) === 100;
                        break;
                    case 8: // Automation Expert
                        shouldUnlock = this.getWeekProgress(5) === 100;
                        break;
                    case 9: // Agent Master
                        shouldUnlock = this.getWeekProgress(6) === 100;
                        break;
                    case 10: // Product Builder
                        shouldUnlock = this.getWeekProgress(7) === 100;
                        break;
                    case 11: // AI Graduate
                        shouldUnlock = completedWeeks >= 7;
                        break;
                }

                if (shouldUnlock) {
                    achievement.unlocked = true;
                    this.data.userProgress.totalPoints += achievement.points;
                    this.showAchievementUnlock(achievement);
                }
            }
        });
    }

    getTotalCompletedTasks() {
        return this.data.weeks.reduce((sum, week) => 
            sum + week.days.filter(day => day.status === 'completed').length, 0);
    }

    getCompletedWeeks() {
        return this.data.weeks.filter(week => 
            week.days.every(day => day.status === 'completed')).length;
    }

    getCompletedTasksInWeek(weekId) {
        const week = this.data.weeks.find(w => w.id === weekId);
        return week.days.filter(day => day.status === 'completed').length;
    }

    getWeekProgress(weekId) {
        const week = this.data.weeks.find(w => w.id === weekId);
        const completedDays = week.days.filter(day => day.status === 'completed').length;
        return Math.round((completedDays / week.days.length) * 100);
    }

    getOverallProgress() {
        const totalTasks = this.data.weeks.reduce((sum, week) => sum + week.days.length, 0);
        const completedTasks = this.getTotalCompletedTasks();
        return Math.round((completedTasks / totalTasks) * 100);
    }

    updateStats() {
        const totalPoints = this.data.userProgress.totalPoints;
        const overallProgress = this.getOverallProgress();

        // Update level based on points
        let level = 'Beginner';
        if (totalPoints >= 2000) level = 'Expert';
        else if (totalPoints >= 1000) level = 'Advanced';
        else if (totalPoints >= 400) level = 'Intermediate';

        this.data.userProgress.currentLevel = level;

        // Update UI elements
        const elements = {
            totalPoints: document.getElementById('totalPoints'),
            currentLevel: document.getElementById('currentLevel'),
            overallProgress: document.getElementById('overallProgress'),
            learningStreak: document.getElementById('learningStreak')
        };

        if (elements.totalPoints) elements.totalPoints.textContent = totalPoints;
        if (elements.currentLevel) elements.currentLevel.textContent = level;
        if (elements.overallProgress) elements.overallProgress.textContent = overallProgress + '%';
        if (elements.learningStreak) elements.learningStreak.textContent = this.data.userProgress.learningStreak + ' days';
    }

    updateCurrentWeekDisplay() {
        const currentWeek = this.getCurrentWeek();
        const weekTitle = document.getElementById('currentWeekTitle');
        const weekProgress = document.getElementById('currentWeekProgress');
        const completedTasks = document.getElementById('completedTasks');
        const weekTimeSpent = document.getElementById('weekTimeSpent');

        if (weekTitle) {
            weekTitle.textContent = `Week ${currentWeek.id} - ${currentWeek.title}`;
        }

        if (weekProgress) {
            const progress = this.getWeekProgress(currentWeek.id);
            weekProgress.style.width = progress + '%';
        }

        if (completedTasks) {
            const completed = this.getCompletedTasksInWeek(currentWeek.id);
            completedTasks.textContent = completed;
        }

        if (weekTimeSpent) {
            // This would be calculated from actual time tracking
            weekTimeSpent.textContent = Math.floor(Math.random() * 10);
        }
    }

    getCurrentWeek() {
        // Find first incomplete week or return last week
        for (let week of this.data.weeks) {
            if (this.getWeekProgress(week.id) < 100) {
                return week;
            }
        }
        return this.data.weeks[this.data.weeks.length - 1];
    }

    showAchievementNotification(points) {
        const notification = document.createElement('div');
        notification.className = 'achievement-notification';
        notification.innerHTML = `
            <i class="fas fa-star"></i>
            <span>+${points} points earned!</span>
        `;
        document.body.appendChild(notification);

        setTimeout(() => {
            notification.remove();
        }, 3000);
    }

    showAchievementUnlock(achievement) {
        const notification = document.createElement('div');
        notification.className = 'achievement-notification';
        notification.innerHTML = `
            <span style="font-size: 1.5em;">${achievement.icon}</span>
            <div>
                <strong>Achievement Unlocked!</strong><br>
                ${achievement.name} (+${achievement.points} points)
            </div>
        `;
        document.body.appendChild(notification);

        setTimeout(() => {
            notification.remove();
        }, 5000);
    }

    renderOverview() {
        this.updateCurrentWeekDisplay();
    }
}

// Initialize dashboard when page loads
document.addEventListener('DOMContentLoaded', () => {
    new LearningDashboard();
});